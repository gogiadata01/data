// let btn = document.querySelectorAll(".btn");
// console.log(btn);
// let body = document.querySelector("body");
// btn.forEach(el => {
//     el.addEventListener("click", function(){
      
//     });
// });




let color = ["#222f3e","#f358e0","#ee5253","#0abde3", "#10ac84"];
let i = 0;
document.querySelector("button").addEventListener("click", function(){
    i = 1 < color.length ? ++i :0;
    document.querySelector("body").style.background = color[i]
})